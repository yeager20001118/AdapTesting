# [[L1 kernels], [L2 kernels]]
KERNEL_LIST = [["laplace", "laplace_gaussian", "gaussian_laplace"],
               ["gaussian", "laplace_gaussian", "gaussian_laplace", "deep"]]
